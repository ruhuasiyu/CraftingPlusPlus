scoreboard objectives add cliValue dummy
scoreboard players set #-1 cliValue -1
scoreboard players set #71 cliValue 71
scoreboard players set #710 cliValue 710
scoreboard players set #7100 cliValue 7100
tellraw @a "物品分类器(1.15+)已加载完毕。"
