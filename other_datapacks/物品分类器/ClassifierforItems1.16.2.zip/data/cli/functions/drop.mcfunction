setblock ~ 255 ~ shulker_box
data modify block ~ 255 ~ Items append from storage cli:dist Item
execute store result block ~ 255 ~ Items[0].Count byte 1 run scoreboard players get #dc cliValue
loot spawn ~ ~ ~ mine ~ 255 ~ tnt{drop_content:1b}
setblock ~ 255 ~ air
