advancement revoke @s only cli:chest
execute anchored eyes positioned ^ ^ ^ run function cli:init/chest_locate
