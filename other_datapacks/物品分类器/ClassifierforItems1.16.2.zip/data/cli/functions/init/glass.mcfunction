advancement revoke @s only cli:glass
execute anchored eyes positioned ^ ^ ^ run function cli:init/glass_locate
