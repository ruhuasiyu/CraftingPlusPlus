function cli:locate/init
execute as @e[type=area_effect_cloud,distance=..10,tag=cli_locate_block] at @s if block ~ ~ ~ #cli:active_blocks run tag @s add cli_locate_block_position
execute at @e[type=area_effect_cloud,distance=..7.1,tag=cli_locate_block_position,sort=nearest,limit=1] if block ~ ~1 ~ #cli:containers align xyz run summon armor_stand ~0.5 ~ ~0.5 {Invulnerable:1b,Invisible:1b,Small:1b,Marker:1b,NoGravity:1b,DisabledSlots:7967,Tags:["cli_glass"]}
kill @e[type=area_effect_cloud,distance=..10,tag=cli_locate_block]
