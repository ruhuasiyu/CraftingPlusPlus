data modify storage cli:dist Item set from block ~ ~1 ~ Items[0]
data modify storage cli:dist Item.Slot set value 0b
data modify storage cli:dist id set from storage cli:dist Item.id
data remove block ~ ~1 ~ Items[0]
execute store result score #dc cliValue run data get storage cli:dist Item.Count
execute as @e[type=#cli:item_frames,distance=..20] if data entity @s Item run function cli:main2
execute if score #dc cliValue matches 1.. positioned ~ ~-1 ~ run function cli:dist/pos
execute if score #dc cliValue matches 1.. positioned ~ ~-1 ~ run function cli:drop
