tellraw @a {"text":"物品分类器数据包已加载完毕。","color":"gold","clickEvent":{"action":"open_url","value":"https://www.mcmod.cn/class/1851.html"}}
