execute unless block ~ ~ ~ #cli:active_blocks run kill @s
execute unless data block ~ ~1 ~ Items run kill @s
execute unless predicate cli:strong if data block ~ ~1 ~ Items[] run function cli:main1
