tag @e[type=area_effect_cloud,distance=..8,tag=cli_locate_block,tag=cli_temp] remove cli_temp
scoreboard players operation #t1 cliValue = #x cliValue
scoreboard players operation #t1 cliValue *= #-1 cliValue
scoreboard players operation #t1 cliValue %= #71 cliValue
execute if score #t1 cliValue matches 0..1 run scoreboard players add #t1 cliValue 71
scoreboard players operation #t1 cliValue *= #71 cliValue
scoreboard players operation #t1 cliValue /= #f cliValue
scoreboard players operation #t2 cliValue = #y cliValue
scoreboard players operation #t2 cliValue *= #-1 cliValue
scoreboard players operation #t2 cliValue %= #71 cliValue
execute if score #t2 cliValue matches 0..1 run scoreboard players add #t2 cliValue 71
scoreboard players operation #t2 cliValue *= #71 cliValue
scoreboard players operation #t2 cliValue /= #g cliValue
scoreboard players operation #t3 cliValue = #z cliValue
scoreboard players operation #t3 cliValue *= #-1 cliValue
scoreboard players operation #t3 cliValue %= #71 cliValue
execute if score #t3 cliValue matches 0..1 run scoreboard players add #t3 cliValue 71
scoreboard players operation #t3 cliValue *= #71 cliValue
scoreboard players operation #t3 cliValue /= #h cliValue
scoreboard players operation #t1 cliValue < #t2 cliValue
scoreboard players operation #t1 cliValue < #t3 cliValue
scoreboard players operation #s1 cliValue = #f cliValue
scoreboard players operation #s2 cliValue = #g cliValue
scoreboard players operation #s3 cliValue = #h cliValue
scoreboard players operation #s1 cliValue *= #t1 cliValue
scoreboard players operation #s2 cliValue *= #t1 cliValue
scoreboard players operation #s3 cliValue *= #t1 cliValue
scoreboard players operation #s1 cliValue /= #71 cliValue
scoreboard players operation #s2 cliValue /= #71 cliValue
scoreboard players operation #s3 cliValue /= #71 cliValue
scoreboard players operation #x cliValue += #s1 cliValue
scoreboard players operation #y cliValue += #s2 cliValue
scoreboard players operation #z cliValue += #s3 cliValue
summon area_effect_cloud ~ ~ ~ {Tags:["cli_locate_block","cli_temp"]}
execute if score #sf cliValue matches 0.. store result entity @e[type=area_effect_cloud,distance=..6.5,tag=cli_locate_block,tag=cli_temp,limit=1] Pos[0] double 0.014084507042254 run scoreboard players get #x cliValue
execute if score #sg cliValue matches 0.. store result entity @e[type=area_effect_cloud,distance=..6.5,tag=cli_locate_block,tag=cli_temp,limit=1] Pos[1] double 0.014084507042254 run scoreboard players get #y cliValue
execute if score #sh cliValue matches 0.. store result entity @e[type=area_effect_cloud,distance=..6.5,tag=cli_locate_block,tag=cli_temp,limit=1] Pos[2] double 0.014084507042254 run scoreboard players get #z cliValue
execute if score #sf cliValue matches ..-1 store result entity @e[type=area_effect_cloud,distance=..6.5,tag=cli_locate_block,tag=cli_temp,limit=1] Pos[0] double -0.014084507042254 run scoreboard players get #x cliValue
execute if score #sg cliValue matches ..-1 store result entity @e[type=area_effect_cloud,distance=..6.5,tag=cli_locate_block,tag=cli_temp,limit=1] Pos[1] double -0.014084507042254 run scoreboard players get #y cliValue
execute if score #sh cliValue matches ..-1 store result entity @e[type=area_effect_cloud,distance=..6.5,tag=cli_locate_block,tag=cli_temp,limit=1] Pos[2] double -0.014084507042254 run scoreboard players get #z cliValue
execute at @e[type=area_effect_cloud,distance=..8,tag=cli_locate_block,tag=cli_temp] if entity @s[distance=..6.5] run function cli:locate/loop1
