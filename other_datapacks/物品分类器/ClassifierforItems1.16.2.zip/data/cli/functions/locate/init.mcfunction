summon area_effect_cloud ^ ^ ^ {Tags:["cli_locate_block"]}
summon area_effect_cloud ^ ^ ^1 {Tags:["cli_locate_block_front"]}
execute store result score #x cliValue run data get entity @e[type=area_effect_cloud,distance=..3,tag=cli_locate_block,limit=1] Pos[0] 71
execute store result score #z cliValue run data get entity @e[type=area_effect_cloud,distance=..3,tag=cli_locate_block,limit=1] Pos[2] 71
scoreboard players operation #tempx cliValue = #x cliValue
execute if score #x cliValue matches ..-1 run scoreboard players operation #tempx cliValue *= #-1 cliValue
scoreboard players operation #tempz cliValue = #z cliValue
execute if score #z cliValue matches ..-1 run scoreboard players operation #tempz cliValue *= #-1 cliValue
scoreboard players operation #tempx cliValue > #tempz cliValue
execute if score #tempx cliValue matches 213000001.. run function cli:locate/init1
execute if score #tempx cliValue matches 21300001..213000000 run function cli:locate/init10
execute if score #tempx cliValue matches ..21300000 run function cli:locate/init100
kill @e[type=area_effect_cloud,tag=cli_locate_block_front]
