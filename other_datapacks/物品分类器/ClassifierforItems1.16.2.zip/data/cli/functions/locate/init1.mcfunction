execute store result score #y cliValue run data get entity @e[type=area_effect_cloud,distance=..3,tag=cli_locate_block,limit=1] Pos[1] 71
execute store result score #f cliValue run data get entity @e[type=area_effect_cloud,distance=..3,tag=cli_locate_block_front,limit=1] Pos[0] 71
execute store result score #g cliValue run data get entity @e[type=area_effect_cloud,distance=..3,tag=cli_locate_block_front,limit=1] Pos[1] 71
execute store result score #h cliValue run data get entity @e[type=area_effect_cloud,distance=..3,tag=cli_locate_block_front,limit=1] Pos[2] 71
scoreboard players operation #f cliValue -= #x cliValue
scoreboard players operation #g cliValue -= #y cliValue
scoreboard players operation #h cliValue -= #z cliValue
scoreboard players operation #sf cliValue = #f cliValue
scoreboard players operation #sg cliValue = #g cliValue
scoreboard players operation #sh cliValue = #h cliValue
execute if score #sf cliValue matches ..-1 run scoreboard players operation #x cliValue *= #-1 cliValue
execute if score #sg cliValue matches ..-1 run scoreboard players operation #y cliValue *= #-1 cliValue
execute if score #sh cliValue matches ..-1 run scoreboard players operation #z cliValue *= #-1 cliValue
execute if score #sf cliValue matches ..-1 run scoreboard players operation #f cliValue *= #-1 cliValue
execute if score #sg cliValue matches ..-1 run scoreboard players operation #g cliValue *= #-1 cliValue
execute if score #sh cliValue matches ..-1 run scoreboard players operation #h cliValue *= #-1 cliValue
function cli:locate/loop1
