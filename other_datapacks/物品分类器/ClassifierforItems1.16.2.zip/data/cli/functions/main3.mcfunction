execute store result score #compare_id cliValue run data modify storage cli:dist Item.id set from entity @s Item.id
execute if score #compare_id cliValue matches 0 at @s run function cli:main4
