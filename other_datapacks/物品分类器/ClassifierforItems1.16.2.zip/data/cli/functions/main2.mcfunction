execute if score #dc cliValue matches 1.. run function cli:main3
data modify storage cli:dist Item.id set from storage cli:dist id
