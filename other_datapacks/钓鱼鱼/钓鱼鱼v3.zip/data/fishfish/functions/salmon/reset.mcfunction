advancement revoke @s only fishfish:salmon
tag @s add fishfish_salmon
