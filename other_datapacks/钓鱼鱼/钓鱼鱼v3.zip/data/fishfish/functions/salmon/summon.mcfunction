execute store result score #f0 fishfish run data get entity @s Pos[0] 100
execute store result score #f1 fishfish run data get entity @s Pos[1] 100
execute store result score #f2 fishfish run data get entity @s Pos[2] 100
summon salmon ~ ~ ~
execute as @e[type=salmon,distance=..0.1,limit=1,sort=nearest] run function fishfish:move
kill @s
