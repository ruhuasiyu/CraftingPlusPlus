execute store result entity @s Motion[0] double 0.001 run scoreboard players operation #p0 fishfish -= #f0 fishfish
execute store result entity @s Motion[1] double 0.001 run scoreboard players operation #p1 fishfish -= #f1 fishfish
execute store result entity @s Motion[2] double 0.001 run scoreboard players operation #p2 fishfish -= #f2 fishfish
