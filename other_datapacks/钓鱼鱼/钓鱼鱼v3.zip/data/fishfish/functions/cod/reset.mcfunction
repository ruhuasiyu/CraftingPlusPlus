advancement revoke @s only fishfish:cod
tag @s add fishfish_cod
