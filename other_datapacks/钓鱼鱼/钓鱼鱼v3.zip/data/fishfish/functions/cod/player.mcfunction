tag @s remove fishfish_cod
execute store result score #p0 fishfish run data get entity @s Pos[0] 100
execute store result score #p1 fishfish run data get entity @s Pos[1] 100
execute store result score #p2 fishfish run data get entity @s Pos[2] 100
execute as @e[type=item,predicate=fishfish:cod,sort=nearest,limit=1] at @s run function fishfish:cod/summon
