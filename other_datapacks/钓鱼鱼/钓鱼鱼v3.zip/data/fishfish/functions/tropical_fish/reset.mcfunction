advancement revoke @s only fishfish:tropical_fish
tag @s add fishfish_tropical_fish
