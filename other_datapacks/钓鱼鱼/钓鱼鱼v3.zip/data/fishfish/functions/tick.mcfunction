execute as @a[tag=fishfish_cod] at @s run function fishfish:cod/player
execute as @a[tag=fishfish_salmon] at @s run function fishfish:salmon/player
execute as @a[tag=fishfish_tropical_fish] at @s run function fishfish:tropical_fish/player
execute as @a[tag=fishfish_pufferfish] at @s run function fishfish:pufferfish/player
