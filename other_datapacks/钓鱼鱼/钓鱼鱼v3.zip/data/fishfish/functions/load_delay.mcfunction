tellraw @a {"text":"[钓鱼鱼] 数据包已加载完毕。","color":"gold","clickEvent":{"action":"open_url","value":"https://www.mcmod.cn/class/4242.html"}}
