scoreboard objectives add fishfish dummy
schedule function fishfish:load_delay 20t
