advancement revoke @s only fishfish:pufferfish
tag @s add fishfish_pufferfish
